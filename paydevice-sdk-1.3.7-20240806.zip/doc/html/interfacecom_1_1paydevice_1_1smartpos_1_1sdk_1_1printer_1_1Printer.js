var interfacecom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1Printer =
[
    [ "close", "interfacecom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1Printer.html#a465c8ab63a28c46385d25f014aa29bb1", null ],
    [ "getType", "interfacecom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1Printer.html#a874a4e8f4b50f58fdcf1a054a3d1eca5", null ],
    [ "open", "interfacecom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1Printer.html#a597267d376bdba44f52594affa1221c8", null ],
    [ "read", "interfacecom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1Printer.html#adb5caf01ec3883978b529bffae761c6b", null ],
    [ "selectBuiltInPrinter", "interfacecom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1Printer.html#a10f7ea24e80d7e2cdf6f7f1932c39c51", null ],
    [ "write", "interfacecom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1Printer.html#a51c5cc1a346d1ef050ed7486e27ce85a", null ]
];