var annotated_dup =
[
    [ "com", null, [
      [ "paydevice", null, [
        [ "smartpos", null, [
          [ "sdk", null, [
            [ "cashdrawer", null, [
              [ "CashDrawer", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1cashdrawer_1_1CashDrawer.html", null ]
            ] ],
            [ "fingerprint", null, [
              [ "FingerPrintManager", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1fingerprint_1_1FingerPrintManager.html", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1fingerprint_1_1FingerPrintManager" ]
            ] ],
            [ "led", null, [
              [ "LedManager", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1led_1_1LedManager.html", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1led_1_1LedManager" ]
            ] ],
            [ "magneticcard", null, [
              [ "MagneticCardManager", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1magneticcard_1_1MagneticCardManager.html", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1magneticcard_1_1MagneticCardManager" ]
            ] ],
            [ "printer", null, [
              [ "Printer", "interfacecom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1Printer.html", "interfacecom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1Printer" ],
              [ "PrinterManager", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1PrinterManager.html", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1PrinterManager" ],
              [ "SerialPortPrinter", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1SerialPortPrinter.html", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1SerialPortPrinter" ],
              [ "UsbPrinter", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1UsbPrinter.html", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1UsbPrinter" ]
            ] ],
            [ "samcard", null, [
              [ "SamCardManager", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1samcard_1_1SamCardManager.html", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1samcard_1_1SamCardManager" ]
            ] ],
            [ "serialport", null, [
              [ "SerialPort", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1serialport_1_1SerialPort.html", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1serialport_1_1SerialPort" ]
            ] ],
            [ "smartcard", null, [
              [ "SmartCardManager", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1smartcard_1_1SmartCardManager.html", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1smartcard_1_1SmartCardManager" ]
            ] ],
            [ "ImageUtils", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1ImageUtils.html", null ],
            [ "SmartPosException", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1SmartPosException.html", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1SmartPosException" ]
          ] ]
        ] ]
      ] ]
    ] ]
];