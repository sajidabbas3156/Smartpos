var searchData=
[
  ['bmptoblackwhite_29',['bmpToBlackWhite',['../classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1ImageUtils.html#a48b52aaaacbbf85ef347b66181e4f439',1,'com::paydevice::smartpos::sdk::ImageUtils']]],
  ['bmptograydithering_30',['bmpToGrayDithering',['../classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1ImageUtils.html#a60aaaf4ac42e314856eddc0452fe602f',1,'com::paydevice::smartpos::sdk::ImageUtils']]]
];
