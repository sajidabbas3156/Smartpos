var searchData=
[
  ['magneticcardmanager_160',['MagneticCardManager',['../classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1magneticcard_1_1MagneticCardManager.html',1,'com::paydevice::smartpos::sdk::magneticcard']]]
];
