var searchData=
[
  ['read_276',['read',['../classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1SerialPortPrinter.html#ac88fdbf3da87cd53a1bd937f2b482a14',1,'com.paydevice.smartpos.sdk.printer.SerialPortPrinter.read()'],['../classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1UsbPrinter.html#aeafaf5aff884e6caa72ee8f4e4b9b1f8',1,'com.paydevice.smartpos.sdk.printer.UsbPrinter.read(byte[] buf, int len)'],['../classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1printer_1_1UsbPrinter.html#aeea3ac23ce53030d5d53a92d27c43e9d',1,'com.paydevice.smartpos.sdk.printer.UsbPrinter.read(byte[] buf, int len, int timeout)']]]
];
