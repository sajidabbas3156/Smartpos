var searchData=
[
  ['query_275',['query',['../classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1magneticcard_1_1MagneticCardManager.html#a75012d07de7206e286255c7ce83cb088',1,'com::paydevice::smartpos::sdk::magneticcard::MagneticCardManager']]]
];
