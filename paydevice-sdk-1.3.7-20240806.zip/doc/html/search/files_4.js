var searchData=
[
  ['magneticcardmanager_2ejava_173',['MagneticCardManager.java',['../MagneticCardManager_8java.html',1,'']]]
];
