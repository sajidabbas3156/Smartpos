var searchData=
[
  ['bmptoblackwhite_209',['bmpToBlackWhite',['../classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1ImageUtils.html#a48b52aaaacbbf85ef347b66181e4f439',1,'com::paydevice::smartpos::sdk::ImageUtils']]],
  ['bmptograydithering_210',['bmpToGrayDithering',['../classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1ImageUtils.html#a60aaaf4ac42e314856eddc0452fe602f',1,'com::paydevice::smartpos::sdk::ImageUtils']]]
];
