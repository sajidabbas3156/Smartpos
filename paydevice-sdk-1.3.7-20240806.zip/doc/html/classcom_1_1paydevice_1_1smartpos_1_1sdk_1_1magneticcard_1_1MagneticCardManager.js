var classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1magneticcard_1_1MagneticCardManager =
[
    [ "deinit", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1magneticcard_1_1MagneticCardManager.html#a79f586eb5af0b1efe6cf43ae5fd9a04e", null ],
    [ "getTrack", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1magneticcard_1_1MagneticCardManager.html#a4443554dd1722049b4fb2072bde4ab54", null ],
    [ "init", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1magneticcard_1_1MagneticCardManager.html#a2bc9c0ab5872a4c9412dbf6a43048bba", null ],
    [ "query", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1magneticcard_1_1MagneticCardManager.html#a75012d07de7206e286255c7ce83cb088", null ]
];