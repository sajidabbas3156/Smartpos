var classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1fingerprint_1_1FingerPrintManager =
[
    [ "compare", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1fingerprint_1_1FingerPrintManager.html#a26ffb4e8ef24b957f6ef7079416098dc", null ],
    [ "deinit", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1fingerprint_1_1FingerPrintManager.html#a39ff2fa2105b060d1ba26b65f6d8123b", null ],
    [ "getBitmapBytes", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1fingerprint_1_1FingerPrintManager.html#ab61c03489607658d1a85982a85f9a9dd", null ],
    [ "getBitmapHeight", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1fingerprint_1_1FingerPrintManager.html#a12a159e84ec338c9f697f7f9dc36d789", null ],
    [ "getBitmapWidth", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1fingerprint_1_1FingerPrintManager.html#ad9b43e89f2e8cc125726eee7bb60abd0", null ],
    [ "getMinutiae", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1fingerprint_1_1FingerPrintManager.html#a0507ed68d478d48453c1aedb99f9c777", null ],
    [ "init", "classcom_1_1paydevice_1_1smartpos_1_1sdk_1_1fingerprint_1_1FingerPrintManager.html#a553cd36721390c4d1cce0e7b8cc9bf45", null ]
];