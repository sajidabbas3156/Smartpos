
package com.paydevice.smartpos.demo;

import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.paydevice.smartpos.demo.smartcard.ISO7816Activity;
import com.paydevice.smartpos.demo.smartcard.AT24CActivity;
import com.paydevice.smartpos.demo.smartcard.SLE4428Activity;
import com.paydevice.smartpos.demo.smartcard.SLE4442Activity;
import com.paydevice.smartpos.demo.smartcard.AT88SC1608Activity;
import com.paydevice.smartpos.demo.smartcard.AT45D041Activity;
import com.paydevice.smartpos.demo.smartcard.SLE6636Activity;
import com.paydevice.smartpos.demo.smartcard.AT88SC102Activity;

public class SmartCardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smartcard);
        setTitle(R.string.smartcard);
    }

	public void onISO7816Click(View v) {
		Intent intent = new Intent(SmartCardActivity.this, ISO7816Activity.class);
		startActivity(intent);
	}

	public void onAT24CClick(View v) {
		Intent intent = new Intent(SmartCardActivity.this, AT24CActivity.class);
		startActivity(intent);
	}

	public void onSLE4428Click(View v) {
		Intent intent = new Intent(SmartCardActivity.this, SLE4428Activity.class);
		startActivity(intent);
	}

	public void onSLE4442Click(View v) {
		Intent intent = new Intent(SmartCardActivity.this, SLE4442Activity.class);
		startActivity(intent);
	}

	public void onAT88SC1608Click(View v) {
		Intent intent = new Intent(SmartCardActivity.this, AT88SC1608Activity.class);
		startActivity(intent);
	}

	public void onAT45D041Click(View v) {
		Intent intent = new Intent(SmartCardActivity.this, AT45D041Activity.class);
		startActivity(intent);
	}

	public void onSLE6636Click(View v) {
		Intent intent = new Intent(SmartCardActivity.this, SLE6636Activity.class);
		startActivity(intent);
	}

	public void onAT88SC102lick(View v) {
		Intent intent = new Intent(SmartCardActivity.this, AT88SC102Activity.class);
		startActivity(intent);
	}
}
