package com.paydevice.smartpos.demo;

import android.content.Context;
import android.widget.Toast;

//for android8.0+ Toast compatibility
public class MyToast {
	private Toast mToast;

	public MyToast(Context context) {
		mToast = Toast.makeText(context, "", Toast.LENGTH_SHORT);
	}

	public void showToast(String text) {
		mToast.setText(text);
		mToast.setDuration(Toast.LENGTH_SHORT);
		mToast.show();
	}

	public void showToast(int resId) {
		mToast.setText(resId);
		mToast.setDuration(Toast.LENGTH_SHORT);
		mToast.show();
	}
	public void cancel() {
		mToast.cancel();
	}
}
