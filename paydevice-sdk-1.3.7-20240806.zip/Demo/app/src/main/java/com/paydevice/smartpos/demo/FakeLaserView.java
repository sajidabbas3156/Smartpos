package com.paydevice.smartpos.demo;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public final class FakeLaserView extends View {

	private final Paint paint;

	public FakeLaserView(Context context, AttributeSet attrs) {
		super(context, attrs);

		paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setColor(Color.RED);
		paint.setAlpha(51);//%20
	}

	public void onDraw(Canvas canvas) {
		canvas.drawRect(1, 0, getMeasuredWidth()-1, getMeasuredHeight(), paint);
	}
}
